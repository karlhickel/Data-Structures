Karl Hickel
2278978
hicke111@chapman.mail.edu
Renae German
CPSC 350

No known errors in my code. Did not test on different machines but runs well on mine. 


References:
Renae German

Power function 
http://www.cplusplus.com/forum/beginner/107564/

Addition of strings
http://www.cplusplus.com/reference/string/string/operator+=/

Opening and closing a file
https://stackoverflow.com/questions/3482064/counting-the-number-of-lines-in-a-text-file

Natural log
http://www.cplusplus.com/reference/cmath/log/

Random Numbers
https://stackoverflow.com/questions/9878965/rand-between-0-and-1

fstream
http://www.cplusplus.com/reference/fstream/fstream/?kw=fstream

Shuffle a string (I believe this is where i found it)
https://ubuntuforums.org/showthread.php?t=1196156


