Karl Hickel
2278978
hicke111@mail.chapman.edu
Rene German
CPSC 350-01



No known errors. Runs well on Karl’s machine. Suleiman get seg errors on his. 

Source files submitted: syntaxChecker.h
			 syntaxCheckerMain.cpp
			 fileReader.h
			 fileReader.cpp


References: 
https://stackoverflow.com/questions/936687/how-do-i-declare-a-2d-array-in-c-using-new
http://www.cplusplus.com/reference/cstdlib/rand/
https://stackoverflow.com/questions/36708370/reading-from-txt-file-into-two-dimensional-array-in-c
https://stackoverflow.com/questions/8109961/loop-through-a-multidimensional-array
https://www.youtube.com/watch?v=by3BA_zjdxg
Rao
Textbook






