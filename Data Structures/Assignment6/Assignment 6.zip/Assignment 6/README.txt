Karl Hickel
2278978
hicke111@mail.chapman.edu
Rene German
CPSC 350-01
Assignment 6



No known errors except there seems to be a problem with the time it takes to do 
quick sort and shell sort. I do have a really fast processor so that probably the reason why it shows up as zero. 

References: 
http://www.cplusplus.com/forum/beginner/18457/
https://www.geeksforgeeks.org/quick-sort/
https://www.sanfoundry.com/c-program-implement-shell-sort/
https://stackoverflow.com/questions/2808398/easily-measure-elapsed-time?utm_medium=organic&utm_source=google_rich_qa&utm_campaign=google_rich_qa

Jayson
Suleiman







